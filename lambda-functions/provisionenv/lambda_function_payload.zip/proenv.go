package provisionenv

import (
	"context"
	"fmt"
	"log"
	"os"

	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/ec2"
)

type Event struct {
	EnvironmentName string `json:"environment_name"`
	TTL             string `json:"ttl"` // Format: "YYYY-MM-DD"
}

func HandleProvisionRequest(ctx context.Context, event Event) (string, error) {
	// Use environment variables for configuration
	amiID := os.Getenv("AMI_ID")
	if amiID == "" {
		amiID = "ami-0c55b159cbfafe1f0" // Default AMI ID
	}

	instanceType := os.Getenv("INSTANCE_TYPE")
	if instanceType == "" {
		instanceType = "t2.micro" // Default instance type
	}

	sess := session.Must(session.NewSession(&aws.Config{
		Region: aws.String("us-east-1"), // Specify the region
	}))
	ec2Svc := ec2.New(sess)

	input := &ec2.RunInstancesInput{
		ImageId:      aws.String(amiID),
		InstanceType: aws.String(instanceType),
		MinCount:     aws.Int64(1),
		MaxCount:     aws.Int64(1),
		TagSpecifications: []*ec2.TagSpecification{
			{
				ResourceType: aws.String("instance"),
				Tags: []*ec2.Tag{
					{Key: aws.String("Environment"), Value: aws.String(event.EnvironmentName)},
					{Key: aws.String("TTL"), Value: aws.String(event.TTL)},
				},
			},
		},
	}

	result, err := ec2Svc.RunInstances(input)
	if err != nil {
		log.Printf("Failed to create instance: %v", err)
		return "", err
	}

	instanceID := *result.Instances[0].InstanceId
	return fmt.Sprintf("Created instance: %s", instanceID), nil
}

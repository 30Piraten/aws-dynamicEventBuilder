package cleanupenv

import (
	"context"
	"fmt"
	"log"
	"time"

	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/ec2"
)

func HandleCleanupRequest(ctx context.Context) error {
	sess := session.Must(session.NewSession())
	ec2Svc := ec2.New(sess)

	instances, err := ec2Svc.DescribeInstances(nil)
	if err != nil {
		log.Fatalf("Failed to describe instances: %v", err)
		return err
	}

	now := time.Now()
	for _, reservation := range instances.Reservations {
		for _, instance := range reservation.Instances {
			tags := make(map[string]string)
			for _, tag := range instance.Tags {
				tags[*tag.Key] = *tag.Value
			}

			if ttl, exists := tags["TTL"]; exists {
				ttlTime, err := time.Parse("2006-01-02", ttl)
				if err != nil {
					log.Printf("Failed to parse TTL: %v", err)
					continue
				}

				if ttlTime.Before(now) {
					_, err := ec2Svc.TerminateInstances(&ec2.TerminateInstancesInput{
						InstanceIds: []*string{instance.InstanceId},
					})
					if err != nil {
						log.Printf("Failed to terminate instance %s: %v", *instance.InstanceId, err)
					} else {
						fmt.Printf("Terminated instance: %s\n", *instance.InstanceId)
					}
				}
			}
		}
	}

	return nil
}
